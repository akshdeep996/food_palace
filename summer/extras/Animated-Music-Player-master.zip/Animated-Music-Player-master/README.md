Animated-Music-Player
=====================

Use CSS animations and JS to rock this music player to the beat!

Watch the [video tutorial on Youtube!](http://youtube.com)

![](thumbnail.png)
